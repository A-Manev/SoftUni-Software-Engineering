﻿namespace BattleCards.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.\SQLEXPRESS;Database=BattleCards;Integrated Security=true;";
    }
}
