﻿using System;

namespace Farm
{
    public class Cat : Animal
    {
        public Cat()
            : base()
        {

        }

        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
