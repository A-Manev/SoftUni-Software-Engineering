﻿using System;

namespace Farm
{
    public class Animal
    {
        public Animal()
        {

        }

        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
