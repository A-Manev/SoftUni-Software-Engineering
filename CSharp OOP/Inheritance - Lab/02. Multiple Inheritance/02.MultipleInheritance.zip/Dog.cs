﻿using System;

namespace Farm
{
    public class Dog : Animal
    {
        public Dog()
            : base()
        {

        }

        public void Bark()
        {
            Console.WriteLine("barking…");
        }
    }
}


