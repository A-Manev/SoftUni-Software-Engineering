﻿using System;

namespace ShoppingSpree
{
    public class StartUp
    {
        public static void Main()
        {
            try
            {
                Engine engine = new Engine();
                engine.Run();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
    }
}
