﻿namespace Zoo.Reptiles
{
    public class Snake : Reptile
    {
        public Snake(string name)
            : base(name)
        {

        }
    }
}
