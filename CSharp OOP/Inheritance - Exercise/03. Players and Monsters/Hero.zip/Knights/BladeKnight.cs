﻿namespace PlayersAndMonsters.Knights
{
    public class BladeKnight : Knight
    {
        public BladeKnight(string username, int level) 
            : base(username, level)
        {

        }
    }
}
