﻿namespace HotelReservation
{
    public enum Season
    {
        Autumn = 1,
        Spring = 2,
        Winter = 3,
        Summer = 4,
    }
}
