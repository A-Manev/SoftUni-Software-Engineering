﻿namespace GreedyTimes
{
    public class Gold : Item
    {
        public Gold(string key, long value)
        {
            this.Key = key;
            this.Value = value;
        }
    }
}
