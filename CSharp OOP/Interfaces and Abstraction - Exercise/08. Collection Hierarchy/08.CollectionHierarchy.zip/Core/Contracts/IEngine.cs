﻿namespace CollectionHierarchy.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
