﻿namespace CollectionHierarchy.Contracts
{
    public interface IRemove
    {
        string Remove();
    }
}
