﻿namespace CollectionHierarchy.Contracts
{
    public interface IUsed
    {
        int Used { get; }
    }
}
