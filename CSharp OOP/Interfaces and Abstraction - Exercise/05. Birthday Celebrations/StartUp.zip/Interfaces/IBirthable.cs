﻿using System;

namespace BirthdayCelebrations.Interfaces
{
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}
