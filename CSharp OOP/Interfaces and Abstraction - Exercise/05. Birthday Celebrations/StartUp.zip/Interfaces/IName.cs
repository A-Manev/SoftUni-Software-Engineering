﻿namespace BirthdayCelebrations.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}
