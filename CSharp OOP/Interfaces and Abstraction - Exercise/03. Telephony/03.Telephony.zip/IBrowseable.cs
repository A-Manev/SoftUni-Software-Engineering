﻿namespace Telephony
{
    public interface IBrowseable : ICallable
    {
        string Browse(string site);
    }
}
