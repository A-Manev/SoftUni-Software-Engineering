﻿namespace Logger.Common
{
    public static class GlobalConstant
    {
        public static string DATE_FORMAT = "M/dd/yyyy h:mm:ss tt";
    }
}
