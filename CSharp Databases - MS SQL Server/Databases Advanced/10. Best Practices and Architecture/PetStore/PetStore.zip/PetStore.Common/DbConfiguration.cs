﻿namespace PetStore.Common
{
    public static class DbConfiguration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=PetStore;Integrated Security=True";
    }
}
