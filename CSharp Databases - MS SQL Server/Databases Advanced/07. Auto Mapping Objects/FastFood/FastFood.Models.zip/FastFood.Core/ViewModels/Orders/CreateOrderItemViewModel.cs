﻿namespace FastFood.Core.ViewModels.Orders
{
    public class CreateOrderItemViewModel
    {
        public int ItemId { get; set; }

        public string ItemName { get; set; }
    }
}
