﻿namespace FastFood.Core.ViewModels.Positions
{
    public class PositionsAllViewModel
    {
        public string Name { get; set; }
    }
}
