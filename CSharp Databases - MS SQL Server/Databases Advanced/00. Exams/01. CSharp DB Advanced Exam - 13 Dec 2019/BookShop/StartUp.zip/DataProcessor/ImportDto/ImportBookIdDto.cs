﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportBookIdDto
    {
        public int? Id { get; set; }
    }
}
